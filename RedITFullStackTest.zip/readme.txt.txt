Technical documentation for the project. 

You need to go into both 'api' and 'client' folder and run commands to start the project. 

##Api documentation
1. Go to the 'api' folder and run 'npm install' 
2. Then run 'npm run dev' for running the api


##Client documentation
# I have removed the node_modules folder from the react project to you can make the file smaller to send you. 
1. Go to the 'client' folder and run 'npm install' 
2. Then run 'npm start' 


Some technical decisions

In the backend api, i have created a function called 'getAllStarwarsPeople'
For collecing all people together. Because the 'https://swapi.py4e.com/api/people/' provides 
only 10 user at a time. For filtering purpose its required all user together. 

I have use 'antd' package for designing purpose. 

I haven't write any test code because of short amount of time. 
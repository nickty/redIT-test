### Backend documentation

### run `npm install`

It will install all requied packages for the backend API

### run `npm run dev`

This command will run the backend API with production mode
